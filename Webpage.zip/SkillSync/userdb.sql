-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2025 at 07:18 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `message` tinytext NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `event_id`, `message`, `created_on`) VALUES
(29, 17, 31, 'qqwqwqw', '2025-06-06 11:29:21'),
(30, 17, 31, 'qwqwqw', '2025-06-06 11:29:24');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `event_date` date NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `youtube_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `user_id`, `title`, `description`, `event_date`, `created_on`, `youtube_url`, `created_at`) VALUES
(31, 17, 'Spam on emails', '.', '2025-06-06', '2025-06-06 09:10:18', 'https://www.youtube.com/watch?v=IRXTLUmLEvQ', '2025-06-06 09:10:18'),
(32, 17, 'Keep your kids safe online', '.', '2025-06-06', '2025-06-06 09:12:31', 'https://www.youtube.com/watch?v=bHZINScB4Jo', '2025-06-06 09:12:31'),
(33, 17, 'Safe password', '.', '2025-06-06', '2025-06-06 09:13:11', 'https://www.youtube.com/watch?v=UXJ6CylECqQ', '2025-06-06 09:13:11'),
(34, 17, 'Cybersecurity Awareness', '.', '2025-06-06', '2025-06-06 09:13:44', 'https://www.youtube.com/watch?v=7cC_KJBJOXE', '2025-06-06 09:13:44');

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`id`, `event_id`, `title`, `created_at`) VALUES
(15, 31, 'Spam on emails', '2025-06-06 11:12:51'),
(16, 32, 'Keep your kids safe online', '2025-06-06 11:33:20'),
(17, 33, 'Safe password', '2025-06-06 11:40:57'),
(18, 34, 'Cybersecurity Awareness', '2025-06-06 11:46:02');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_questions`
--

CREATE TABLE `quiz_questions` (
  `id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `question_text` text NOT NULL,
  `option_a` varchar(255) NOT NULL,
  `option_b` varchar(255) NOT NULL,
  `option_c` varchar(255) NOT NULL,
  `option_d` varchar(255) NOT NULL,
  `correct_option` enum('a','b','c','d') NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_questions`
--

INSERT INTO `quiz_questions` (`id`, `quiz_id`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `created_at`) VALUES
(8, 15, 'What should you do if you get an email from someone you don’t know with a link in it?', 'Click the link just to see what it is', 'Forward it to your friend', 'Delete or report the email', 'Reply and say “Who are you?”', 'c', '2025-06-06 11:12:51'),
(9, 15, 'Why should you avoid clicking strange links in emails?', 'They might take you to a cool website', 'They could steal your personal information or infect your device', 'They improve your internet speed', 'They give you rewards', 'b', '2025-06-06 11:12:51'),
(10, 15, 'What is a common sign of a phishing email?', 'It uses formal language', 'It says “Hello”', 'It creates urgency and asks you to act fast', 'It comes from your email address', 'c', '2025-06-06 11:12:51'),
(11, 15, 'What does “phishing” mean in cybersecurity?', 'A new type of fishing game', 'Sending emails to catch viruses', 'Tricking people into giving away personal information', 'Shopping online safely', 'c', '2025-06-06 11:12:51'),
(12, 15, 'What is the safest way to check if a link is legitimate?', 'Click it and see where it goes', 'Hover your mouse over the link to preview the URL', 'Copy and paste it into a search engine', 'Ignore the email entirely', 'b', '2025-06-06 11:12:51'),
(13, 15, 'If an email asks for your password or bank info, what should you do?', 'Provide the info quickly', 'Ask your friend if it’s okay', 'Double-check by calling the sender using a known number', 'Reply and say “No thanks”', 'c', '2025-06-06 11:12:51'),
(14, 15, 'Which of these email senders might be fake?', 'support@yourbank.com', 'yourbank123@gmail.com', 'help@company.com', 'info@trusted.org', 'b', '2025-06-06 11:12:51'),
(15, 15, 'What happens if you click a malicious link?', 'Nothing', 'You might win a free phone', 'Your device might get hacked or infected with malware', 'Your battery charges faster', 'c', '2025-06-06 11:12:51'),
(16, 15, 'Why do cybercriminals send phishing emails?', 'To test your memory', 'To help you update your apps', 'To steal your identity, money, or information', 'To remind you to check your inbox', 'c', '2025-06-06 11:12:51'),
(17, 15, 'What’s the best general rule for email safety?', 'Click all links to be sure they work', 'Trust every message that looks urgent', 'Think before you click and verify the sender', 'Respond to all emails quickly', 'c', '2025-06-06 11:12:51'),
(18, 16, 'Why is it important to talk to kids about internet safety?', 'Why is it important to talk to kids about internet safety?', 'So they don’t get bored', 'So they know how to protect themselves online', 'So they learn how to download faster', 'c', '2025-06-06 11:33:20'),
(19, 16, 'What should a child do if someone online asks for their personal information?', 'Give it to be polite', 'Tell a trusted adult immediately', 'Keep it a secret', 'Ask the person for their info first', 'b', '2025-06-06 11:33:20'),
(20, 16, 'What kind of information should kids never share online?', 'Favorite color', 'Name of their pet', 'Home address, phone number, or school', 'Favorite cartoon', 'c', '2025-06-06 11:33:20'),
(21, 16, 'If a kid sees something online that makes them uncomfortable, what should they do?', 'Ignore it', 'Keep it secret', 'Tell a trusted adult right away', 'Share it with friends', 'c', '2025-06-06 11:33:20'),
(22, 16, 'Which password is safest for a child to use?', '123456', 'Their name and birthdate', 'A mix of letters, numbers, and symbols', 'The word “password”', 'c', '2025-06-06 11:33:20'),
(23, 16, 'Why should kids never meet someone in person that they only know online?', 'It’s not fun', 'It might be boring', 'It can be dangerous', 'It costs money', 'c', '2025-06-06 11:33:20'),
(24, 16, 'What’s one way adults can help kids stay safe online?', 'Let them use any app they want', 'Never check what they’re doing', 'Set rules and talk regularly about online safety', 'Give them a phone at age 3', 'c', '2025-06-06 11:33:20'),
(25, 16, 'What is cyberbullying?', 'A fun online game', 'Being mean or hurtful to someone using the internet', 'Sending stickers in chat', 'Making funny videos', 'b', '2025-06-06 11:33:20'),
(26, 16, 'What should kids do if someone is bullying them online?', 'Delete their account', 'Bully them back', 'Tell a parent, teacher, or trusted adult', 'Ignore it forever', 'c', '2025-06-06 11:33:20'),
(27, 16, 'Why is using privacy settings on apps and games important?', 'To make the app run faster', 'To block pop-up ads', 'To control who can see your information', 'To win more games', 'c', '2025-06-06 11:33:20'),
(28, 17, 'Why is it important to have a strong password?', 'To make your account look cool', 'To avoid remembering it', 'To protect your account from hackers', 'To protect your account from hackers', 'c', '2025-06-06 11:40:57'),
(29, 17, 'Which of the following is the strongest password?', 'password123', 'ilovecats', 'Mx$7Lp!92qK#', 'john2000', 'c', '2025-06-06 11:40:57'),
(30, 17, 'How often should you change your passwords?', 'Never', 'Only if you forget it', 'Once every few months or after a breach', 'Every day', 'c', '2025-06-06 11:40:57'),
(31, 17, 'Is it safe to use the same password on every website?', 'Yes, it’s easier to remember', 'Only if it\'s a strong password', 'No, if one site is hacked, all your accounts are at risk', 'Yes, if you only use trusted sites', 'c', '2025-06-06 11:40:57'),
(32, 17, 'What should you do if someone finds out your password?', 'Use it anyway', 'Share it with more people', 'Change it immediately', 'Ignore it', 'c', '2025-06-06 11:40:57'),
(33, 17, 'Where is the safest place to store your passwords?', 'A sticky note on your desk', 'In your phone notes app', 'A password manager', 'In your head only', 'c', '2025-06-06 11:40:57'),
(34, 17, 'What is a passphrase?', 'A code with numbers only', 'A short version of a password', 'A long, easy-to-remember sentence made up of words, numbers, and symbols', 'A computer command', 'c', '2025-06-06 11:40:57'),
(35, 17, 'Which is a poor password practice?', 'Using different passwords for each account', 'Using your pet’s name and birth year', 'Enabling two-factor authentication', 'Keeping your password private', 'b', '2025-06-06 11:40:57'),
(36, 17, 'What is two-factor authentication (2FA)?', 'A way to reset your password', 'A backup email service', 'A second step to confirm your identity (like a code or app)', 'A trick hackers use', 'c', '2025-06-06 11:40:57'),
(37, 17, 'What does a good password NOT include?', 'Personal info like your name or birthday', 'Random letters, numbers, and symbols', 'Upper and lowercase letters', 'Special characters like @, #, or $', 'a', '2025-06-06 11:40:57'),
(38, 18, 'What is cybersecurity?', 'A way to protect your car from being stolen', 'Protecting computers and data from hackers and threats', 'A video game', 'A setting on your phone', 'a', '2025-06-06 11:46:02'),
(39, 18, 'What is a strong password made of?', 'Only your name', 'Only numbers', 'Letters, numbers, and symbols', 'Something easy to remember', 'a', '2025-06-06 11:46:02'),
(40, 18, 'What is “phishing”?', 'Fishing on the weekend', 'A fake message or email trying to steal your information', 'A type of app', 'A strong password', 'a', '2025-06-06 11:46:02'),
(41, 18, 'Which of these is a sign of a suspicious email?', 'It has perfect grammar', 'It asks you to click a strange link', 'It’s from your coworker', 'It says “Thank you”', 'a', '2025-06-06 11:46:02'),
(42, 18, 'What should you do if you get a message from an unknown person asking for personal info?', 'Give it to them', 'Block and report the message', 'Ask them why', 'Share it with friends', 'a', '2025-06-06 11:46:02'),
(43, 18, 'How often should you update your antivirus software?', 'Never', 'Once a year', 'Only when your computer crashes', 'Regularly, to stay protected', 'a', '2025-06-06 11:46:02'),
(44, 18, 'What is the purpose of two-factor authentication (2FA)?', 'To confuse hackers', 'To make logging in faster', 'To add an extra layer of security', 'To replace passwords', 'a', '2025-06-06 11:46:02'),
(45, 18, 'Is it safe to use public Wi-Fi to check your bank account?', 'Yes, if it\'s fast', 'No, it can be risky', 'Only if you trust the coffee shop', 'Always safe with headphones', 'a', '2025-06-06 11:46:02'),
(46, 18, 'What should you do if you think your account was hacked?', 'Log out and ignore it', 'Change your password immediately and report it', 'Create a new email', 'Tell your friends only', 'a', '2025-06-06 11:46:02'),
(47, 18, 'Why should you back up your files regularly?', 'To use more space', 'In case your device is lost, stolen, or hacked', 'To update your apps', 'To make your computer faster', 'a', '2025-06-06 11:46:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `type` enum('user','admin') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `type`) VALUES
(10, 'Test User2', '$2y$10$pxELnzIwc/k8wHq/f0zYBePhFN6dxJIH0CMC/LF9Kz4Ohaol8a.fC', 'user@gmail.com', 'user'),
(17, 'Test Admin', '$2y$10$hmHvYJtyz5Mst/mC.GcMB.pmvRZWlJHuvNL0PMcfNvmvdr623i5Fe', 'admin@gmail.com', 'admin'),
(18, 'Test User1', '$2y$10$RzPtAG8OReWj7q0rmbGrPe0FwjCZOCqWwIbA.pEdhF0u8U39xeHPO', 'user1@gmail.com', 'user'),
(20, 'RESHMA ', '$2y$10$L3GFUAJ/CBxDEFbUJMzbaO0CHWhd.vPZ5GE/1/6.B2fov41ndeDlq', 'lisik707@gmail.com', 'user'),
(21, 'alex', '$2y$10$c.8V1gFRGxGOndIG3sgJvudcvbX8UO/w84WzXX3zzCpH5EAWEqYaq', 'alexandrut@gmail.com', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`) USING BTREE;

--
-- Indexes for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `quizzes`
--
ALTER TABLE `quizzes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD CONSTRAINT `quiz_questions_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
