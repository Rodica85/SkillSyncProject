<?php
session_start();

include_once '../includes/database.php';
require_once '../includes/helpers.php';

if (!isLogged() || userType('user')) {
    header('Location: /');
    exit;
}

// --- Events ---
$eventsParams = [];
if (userType('user')) {
    $eventsParams['user_id'] = userId();
}
if (!empty($_GET['keyword'])) {
    $eventsParams['keyword'] = $_GET['keyword'];
}
$events = getEvents($eventsParams);

// --- Quizzes (no filtering because quizzes table has no user_id column) ---
$quizzes = getMany("SELECT * FROM quizzes ORDER BY id DESC", []);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/" />
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <title>SkillSync Dashboard</title>
</head>
<body>
    <?php require_once '../includes/menu.php'; ?>
    <?php require_once '../includes/system_message.php'; ?>

    <div class="container">
        <h2>Welcome, <?php echo userName(); ?>!</h2>

        <!-- Search form -->
        <form action="/dashboard" method="get" class="search-form">
            <input type="text" name="keyword" placeholder="Search keyword..." value="<?php echo htmlspecialchars($_GET['keyword'] ?? '', ENT_QUOTES); ?>">
            <button type="submit" class="default-btn">Search</button>
            <?php if (!empty($_GET['keyword'])) { ?>
                <a href="/dashboard" class="default-btn cancel-btn">Cancel</a>
            <?php } ?>
        </form>

        <!-- EVENTS TABLE -->
        <h3 class="heading-with-button">
            Events
            <?php if (userType('admin')) { ?>
                <a href="/dashboard/user/events/add-event.php" class="default-btn">Add Event</a>
            <?php } ?>
        </h3>

        <table>
            <thead>
                <tr>
                    <th width="50">ID</th>
                    <th width="100">Video</th>
                    <th>Title</th>
                    <?php if (userType('admin')) { ?>
                        <th width="200">User</th>
                    <?php } ?>
                    <th width="150">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($events)) { ?>
                    <tr><td colspan="<?php echo userType('admin') ? 5 : 4; ?>">No events found.</td></tr>
                <?php } else { ?>
                    <?php foreach ($events as $event) { ?>
                        <tr>
                            <td><?php echo $event['id']; ?></td>
                            <td>
                                <?php
                                if (!empty($event['youtube_url'])) {
                                    $url = $event['youtube_url'];
                                    $host = parse_url($url, PHP_URL_HOST);
                                    if (strpos($host, 'youtu.be') !== false) {
                                        $videoId = ltrim(parse_url($url, PHP_URL_PATH), '/');
                                    } else {
                                        parse_str(parse_url($url, PHP_URL_QUERY), $videoParams);
                                        $videoId = $videoParams['v'] ?? '';
                                    }
                                    if ($videoId) {
                                        echo '<iframe width="120" height="70" src="https://www.youtube.com/embed/' . htmlspecialchars($videoId, ENT_QUOTES) . '" frameborder="0" allowfullscreen></iframe>';
                                    } else {
                                        echo 'Invalid video';
                                    }
                                } else {
                                    echo 'No video';
                                }
                                ?>
                            </td>
                            <td><?php echo htmlspecialchars($event['title'], ENT_QUOTES); ?></td>
                            <?php if (userType('admin')) { ?>
                                <td><?php echo htmlspecialchars($event['username'] ?? 'Unknown', ENT_QUOTES); ?></td>
                            <?php } ?>
                            <td>
                                <a href="/dashboard/user/events/edit-event.php?id=<?php echo $event['id']; ?>" class="default-btn">Edit</a>
                                <a href="/actions/events.php?action=delete-event&id=<?php echo $event['id']; ?>" class="danger-btn" onclick="return confirm('Are you sure you want to delete this event?');">Delete</a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>

        <!-- QUIZZES TABLE -->
        <h3 class="heading-with-button">
            Quizzes
            <?php if (userType('admin')) { ?>
                <a href="/dashboard/admin/quiz_add.php" class="default-btn">Add Quiz</a>
            <?php } ?>
        </h3>

        <table>
            <thead>
                <tr>
                    <th width="50">ID</th>
                    <th>Title</th>
                    <th width="150">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($quizzes)) { ?>
                    <tr><td colspan="3">No quizzes found.</td></tr>
                <?php } else { ?>
                    <?php foreach ($quizzes as $quiz) { ?>
                        <tr>
                            <td><?php echo $quiz['id']; ?></td>
                            <td><?php echo htmlspecialchars($quiz['title'], ENT_QUOTES); ?></td>
                            <td>
                                <a href="/dashboard/admin/quiz_edit.php?id=<?php echo $quiz['id']; ?>" class="default-btn">Edit</a>
                                <a href="/actions/quiz.php?action=delete&id=<?php echo $quiz['id']; ?>" class="danger-btn" onclick="return confirm('Are you sure you want to delete this quiz?');">Delete</a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <?php require_once '../includes/footer.php'; ?>
</body>
</html>
