<?php
session_start();

require_once '../../includes/database.php';
require_once '../../includes/helpers.php';

if (!isLogged() || !userType('admin')) {
    header('Location: /');
    exit;
}

$id = (int)($_GET['id'] ?? 0);
if ($id === 0) {
    flashMessageSet("Invalid quiz ID.", "error");
    header('Location: /dashboard/admin/quiz.php');
    exit;
}

$quiz = getQuiz($id);
if (!$quiz) {
    flashMessageSet("Quiz not found.", "error");
    header('Location: /dashboard/admin/quiz.php');
    exit;
}

$events = getMany("SELECT id, title FROM events ORDER BY id DESC");
$questions = getQuizQuestions($id);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quiz_title = trim($_POST['quiz_title'] ?? '');
    $event_id = (int)($_POST['event_id'] ?? 0);

    if ($quiz_title === '' || $event_id === 0) {
        flashMessageSet("Quiz title and event are required.", "error");
    } else {
        updateQuiz($id, ['title' => $quiz_title, 'event_id' => $event_id]);

        // Handle question updates
        if (!empty($_POST['questions']) && is_array($_POST['questions'])) {
            foreach ($_POST['questions'] as $qid => $qdata) {
                updateQuizQuestion((int)$qid, [
                    'question_text' => $qdata['question_text'],
                    'option_a' => $qdata['option_a'],
                    'option_b' => $qdata['option_b'],
                    'option_c' => $qdata['option_c'],
                    'option_d' => $qdata['option_d'],
                    'correct_option' => $qdata['correct_option'],
                ]);
            }
        }

        flashMessageSet("Quiz and questions updated.", "success");
        header('Location: /dashboard/admin/quiz.php');
        exit;
    }
}

function old($field, $default = '') {
    return htmlspecialchars($_POST[$field] ?? $default);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/" />
    <meta charset="UTF-8">
    <title>Edit Quiz</title>
    <link rel="stylesheet" href="/assets/css/style.css" />
</head>
<body>
<?php require_once '../../includes/menu.php'; ?>
<?php require_once '../../includes/system_message.php'; ?>
<div class="container">
    <h2>Edit Quiz</h2>

    <form method="post">
        <label>Quiz Title:<br>
            <input type="text" name="quiz_title" value="<?php echo old('quiz_title', $quiz['title']); ?>" required>
        </label><br><br>

        <label>Event:<br>
            <select name="event_id" required>
                <option value="">-- Select Event --</option>
                <?php foreach ($events as $e): ?>
                    <option value="<?php echo $e['id']; ?>" <?php echo ($quiz['event_id'] == $e['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($e['title']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label><br><br>

        <h3>Edit Questions</h3>
        <?php foreach ($questions as $q): ?>
            <div style="margin-bottom: 20px; padding: 10px; border: 1px solid #ccc;">
                <strong>Question ID: <?php echo $q['id']; ?></strong><br>
                <input type="text" name="questions[<?php echo $q['id']; ?>][question_text]" value="<?php echo htmlspecialchars($q['question_text']); ?>" placeholder="Question text" required><br>
                A: <input type="text" name="questions[<?php echo $q['id']; ?>][option_a]" value="<?php echo htmlspecialchars($q['option_a']); ?>" required><br>
                B: <input type="text" name="questions[<?php echo $q['id']; ?>][option_b]" value="<?php echo htmlspecialchars($q['option_b']); ?>" required><br>
                C: <input type="text" name="questions[<?php echo $q['id']; ?>][option_c]" value="<?php echo htmlspecialchars($q['option_c']); ?>" required><br>
                D: <input type="text" name="questions[<?php echo $q['id']; ?>][option_d]" value="<?php echo htmlspecialchars($q['option_d']); ?>" required><br>
                Correct Option:
                <select name="questions[<?php echo $q['id']; ?>][correct_option]">
                    <?php foreach (["A", "B", "C", "D"] as $opt): ?>
                        <option value="<?php echo $opt; ?>" <?php echo ($q['correct_option'] == $opt) ? 'selected' : ''; ?>><?php echo $opt; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        <?php endforeach; ?>

        <input type="submit" value="Save Changes" class="default-btn">
        <a href="/dashboard/admin/quiz.php" class="default-btn">Cancel</a>
    </form>
</div>

<?php require_once '../../includes/footer.php'; ?>
</body>
</html>
