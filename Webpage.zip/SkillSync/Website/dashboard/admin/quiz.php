<?php
session_start();

require_once '../../includes/database.php';
require_once '../../includes/helpers.php';

if (!isLogged()) {
    header('Location: /');
    exit;
}

// Fetch quizzes with their events info
function fetchQuizzesWithEvents() {
    $query = "
        SELECT q.id AS quiz_id, e.id AS event_id, e.title AS event_title, e.description AS event_description
        FROM quizzes q
        JOIN events e ON q.event_id = e.id
        ORDER BY q.id DESC
    ";
    return getMany($query);
}

$quizzes = fetchQuizzesWithEvents();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/" />
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <title>Available Quizzes</title>
</head>
<body>
<?php require_once '../../includes/menu.php'; ?>
<?php require_once '../../includes/system_message.php'; ?>

<div class="quiz-list-container">
    <h2>Available Quizzes</h2>

    <?php if (userType('admin')): ?>
        <p style="margin-bottom: 20px;">
            <a href="/dashboard/admin/quiz_add.php" class="default-btn">➕ Add Quiz Questions</a>
        </p>
    <?php endif; ?>

    <?php if (count($quizzes) === 0): ?>
        <p>No quizzes available at the moment.</p>
    <?php else: ?>
        <?php foreach ($quizzes as $quiz): ?>
            <div class="quiz-card">
                <h3><?php echo htmlspecialchars($quiz['event_title']); ?></h3>
                 <a href="/actions/take_quiz.php?quiz_id=<?php echo $quiz['quiz_id']; ?>" class="default-btn">Take Quiz</a>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require_once '../../includes/footer.php'; ?>
</body>
</html>
