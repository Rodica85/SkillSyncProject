<?php
session_start();

require_once '../../includes/database.php';
require_once '../../includes/helpers.php';

if (!isLogged() || !userType('admin')) {
    header('Location: /');
    exit;
}

$events = getMany("SELECT id, title FROM events ORDER BY id DESC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $event_id = (int) ($_POST['event_id'] ?? 0);
    $quiz_title = trim($_POST['quiz_title'] ?? '');

    if ($event_id === 0) {
        flashMessageSet("Please select a valid event.", "error");
    } elseif ($quiz_title === '') {
        flashMessageSet("Quiz title is required.", "error");
    } else {
        $conn = getConnection();
        $stmt = $conn->prepare("INSERT INTO quizzes (event_id, title, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $event_id, $quiz_title);

        if ($stmt->execute()) {
            $quiz_id = $stmt->insert_id;
            $hasError = false;

            for ($i = 1; $i <= 10; $i++) {
                $question = trim($_POST["question_$i"] ?? '');
                $option_a = trim($_POST["option_a_$i"] ?? '');
                $option_b = trim($_POST["option_b_$i"] ?? '');
                $option_c = trim($_POST["option_c_$i"] ?? '');
                $option_d = trim($_POST["option_d_$i"] ?? '');
                $correct = strtoupper(trim($_POST["correct_answer_$i"] ?? ''));

                if ($question !== '') {
                    if ($option_a === '' || $option_b === '' || $option_c === '' || $option_d === '' || !in_array($correct, ['A', 'B', 'C', 'D'])) {
                        flashMessageSet("All options and a valid correct answer are required for question #$i.", "error");
                        $hasError = true;
                        continue;
                    }

                    $stmtQ = $conn->prepare("INSERT INTO quiz_questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmtQ->bind_param("issssss", $quiz_id, $question, $option_a, $option_b, $option_c, $option_d, $correct);

                    if (!$stmtQ->execute()) {
                        flashMessageSet("Failed to add question #$i.", "error");
                        $hasError = true;
                    }

                    $stmtQ->close();
                }
            }

            if (!$hasError) {
                flashMessageSet("Quiz and questions added successfully!", "success");
            }

        } else {
            flashMessageSet("Failed to create quiz.", "error");
        }

        $stmt->close();
        $conn->close();
    }
}

function old($field) {
    return htmlspecialchars($_POST[$field] ?? '');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/" />
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <title>Add Quiz</title>
</head>
<body>

<?php require_once '../../includes/menu.php'; ?>
<?php require_once '../../includes/system_message.php'; ?>

<div class="container">
    <h2>Add Quiz & Questions</h2>

    <form method="post">
        <label>Quiz Title:<br>
            <input type="text" name="quiz_title" value="<?php echo old('quiz_title'); ?>" required>
        </label>
        <br><br>

        <label>Select Event:<br>
            <select name="event_id" required>
                <option value="">-- Select Event --</option>
                <?php foreach ($events as $e): ?>
                    <option value="<?php echo $e['id']; ?>" <?php echo (old('event_id') == $e['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($e['title']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <br><br>

        <?php for ($i = 1; $i <= 10; $i++): ?>
            <fieldset class="form-section">
                <legend>Question #<?php echo $i; ?></legend>

                <label>Question:<br>
                    <textarea name="question_<?php echo $i; ?>"><?php echo old("question_$i"); ?></textarea>
                </label><br>

                <label>Option A:<br>
                    <input type="text" name="option_a_<?php echo $i; ?>" value="<?php echo old("option_a_$i"); ?>">
                </label><br>

                <label>Option B:<br>
                    <input type="text" name="option_b_<?php echo $i; ?>" value="<?php echo old("option_b_$i"); ?>">
                </label><br>

                <label>Option C:<br>
                    <input type="text" name="option_c_<?php echo $i; ?>" value="<?php echo old("option_c_$i"); ?>">
                </label><br>

                <label>Option D:<br>
                    <input type="text" name="option_d_<?php echo $i; ?>" value="<?php echo old("option_d_$i"); ?>">
                </label><br>

                <label>Correct Answer:<br>
                    <select name="correct_answer_<?php echo $i; ?>">
                        <option value="">-- Select --</option>
                        <?php foreach (['A', 'B', 'C', 'D'] as $opt): ?>
                            <option value="<?php echo $opt; ?>" <?php echo (old("correct_answer_$i") === $opt) ? 'selected' : ''; ?>><?php echo $opt; ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </fieldset>
        <?php endfor; ?>

        <input type="submit" value="Add Quiz" class="default-btn">
        <a href="/dashboard/admin/quiz.php" class="default-btn">Back to Quizzes</a>
    </form>
</div>

<?php require_once '../../includes/footer.php'; ?>
</body>
</html>
                            