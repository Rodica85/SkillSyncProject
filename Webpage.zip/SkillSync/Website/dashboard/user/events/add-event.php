<?php
session_start();
include_once '../../../includes/database.php';
require_once '../../../includes/helpers.php';

if (!isLogged()) {
    header('Location: /');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/" />
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="/assets/css/style.css" />
    <title>Add Event</title>
</head>
<body>
    <?php require_once '../../../includes/menu.php'; ?>
    <?php require_once '../../../includes/system_message.php'; ?>

    <div class="container">
        <h3>Add Event</h3>
        <div class="add-event-form">
            <form action="/actions/events.php?action=create-event" method="post">
                <div>
                    <label for="date">Event Date</label><br>
                    <input
                      type="date"
                      name="date"
                      id="date"
                      value="<?php echo date('Y-m-d'); ?>"
                      min="<?php echo date('Y-m-d'); ?>"
                      required
                    />
                </div>
                <div>
                    <label for="title">Title</label><br>
                    <input
                      type="text"
                      name="title"
                      id="title"
                      required
                    />
                </div>
                <div>
                    <label for="description">Description</label><br>
                    <textarea
                      name="description"
                      id="description"
                      rows="10"
                      required
                    ></textarea>
                </div>
                <div>
                    <label for="youtube_url">YouTube Video URL</label><br>
                    <input
                      type="url"
                      name="youtube_url"
                      id="youtube_url"
                      placeholder="https://www.youtube.com/watch?v=..."
                      pattern="https?://(www\.)?(youtube\.com|youtu\.be)/.+"
                      title="Enter a valid YouTube URL"
                      required
                    />
                </div>
                <div class="buttons">
                    <input
                      type="submit"
                      name="submit_data"
                      value="Submit"
                      class="default-btn"
                    />
                    <a href="/dashboard" class="danger-btn">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <?php require_once '../../../includes/footer.php'; ?>
</body>
</html>
