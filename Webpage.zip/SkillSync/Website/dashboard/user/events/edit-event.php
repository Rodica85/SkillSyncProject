<?php
session_start();

include_once '../../../includes/database.php';
require_once '../../../includes/helpers.php';

if (!isLogged()) {
    header('Location: /');
    exit;
}

if (empty($_GET['id']) || (int) $_GET['id'] == 0) {
    redirectToDashboard();
    exit;
}

$event = getEvent((int) $_GET['id']);
if (empty($event)) {
    flashMessageSet("Provided Event does not exist.", "error");
    redirectToDashboard();
    exit;
}

if ($event['user_id'] != userId() && userType('user')) {
    flashMessageSet("You do not have access to edit this Event.", "error");
    redirectToDashboard();
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/" />
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
    <link rel="stylesheet" href="/assets/css/style.css" />
    <title>Edit Event</title>
</head>
<body>
    <?php require_once '../../../includes/menu.php'; ?>
    <?php require_once '../../../includes/system_message.php'; ?>

    <div class="container">
        <h3>Edit Event</h3>
        <div class="add-event-form">
            <form action="/actions/events.php?action=update-event" method="post">
                <div>
                    <label for="date">Event Date</label>
                    <input
                        type="date"
                        name="date"
                        id="date"
                        value="<?php echo date('Y-m-d', strtotime($event['event_date'])); ?>"
                        min="<?php echo date('Y-m-d'); ?>"
                        required
                    />
                </div>
                <div>
                    <label for="title">Title</label>
                    <input
                        name="title"
                        type="text"
                        id="title"
                        value="<?php echo htmlspecialchars($event['title']); ?>"
                        required
                    />
                </div>
                <div>
                    <label for="description">Description</label>
                    <textarea
                        name="description"
                        id="description"
                        rows="10"
                        required
                    ><?php echo htmlspecialchars($event['description']); ?></textarea>
                </div>
                <div>
                    <label for="youtube_url">YouTube Video URL</label>
                    <input
                        type="url"
                        name="youtube_url"
                        id="youtube_url"
                        value="<?php echo htmlspecialchars($event['youtube_url']); ?>"
                        placeholder="https://www.youtube.com/watch?v=..."
                        pattern="https?://(www\.)?(youtube\.com|youtu\.be)/.+"
                        title="Enter a valid YouTube URL"
                        required
                    />
                </div>

                <input type="hidden" name="id" value="<?php echo $event['id']; ?>">

                <div class="buttons">
                    <input type="submit" name="submit_data" value="Update" class="default-btn" />
                    <a href="/dashboard" class="danger-btn">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <?php require_once '../../../includes/footer.php'; ?>
</body>
</html>
