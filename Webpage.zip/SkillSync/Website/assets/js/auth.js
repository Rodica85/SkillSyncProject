$(() => {
    const showPopupBtn = $(".login-form");
    const formPopup = $(".auth-form-popup");
    const hidePopupBtn = formPopup.find(".close-btn");
    const signUpLink = formPopup.find("#signup-link");
    const signInLink = formPopup.find('#login-link');

    // Show Popup
    showPopupBtn.on("click", (e) => {
        e.preventDefault();
        $('body').addClass("show-popup");
        formPopup.addClass("open");
    });

    hidePopupBtn.on("click", (e) =>  {
        e.preventDefault();
        $('body').removeClass("show-popup");
        formPopup.removeClass("open");
    });
    
    signUpLink.on("click", (e) =>  {
        e.preventDefault();

        formPopup.toggleClass("show-signup");
    });

    signInLink.on("click", (e) =>  {
        e.preventDefault();
        formPopup.toggleClass("show-signup");
    });
});