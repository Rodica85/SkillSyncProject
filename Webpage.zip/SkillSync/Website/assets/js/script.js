$(function() {
    const navbarMenu = $(".navbar .links");
    const hamburgerBtn = $(".hamburger-btn");
    const hideMenuBtn = navbarMenu.find(".close-btn");

    // Show mobile menu
    hamburgerBtn.on("click", () => {
        navbarMenu.toggleClass("show-menu");
    });

    // Hide mobile menu
    hideMenuBtn.on("click", () =>  {
        navbarMenu.removeClass("show-menu");
    });

    $('.system-message button').on('click', () => {
        $('.system-message').remove();
    });
});




// Show login popup
// showPopupBtn.addEventListener("click", () => {
//     document.body.classList.toggle("show-popup");
// });

// Hide login popup
// hidePopupBtn.addEventListener("click", () => showPopupBtn.click());

// Show or hide signup form
// signupLoginLink.forEach(link => {
//     link.addEventListener("click", (e) => {
//         e.preventDefault();
//         formPopup.classList[link.id === 'signup-link' ? 'add' : 'remove']("show-signup");
//     });
// });
// // Function to show the success message
// function showSuccessMessage() {
//     const successMessage = document.getElementById("success-message");
//     successMessage.style.display = "show";
// }

// // Function to hide the success message
// function hideSuccessMessage() {
//     const successMessage = document.getElementById("success-message");
//     successMessage.style.display = "none";
// }

// Show success message when the signup is successful
// Replace this line with your actual logic to determine signup success
// For demonstration purposes, I'm using a hypothetical condition
// if (signupSuccessful) {
//     showSuccessMessage();
// }

// Add event listeners to hide the success message when the form is opened or closed

// showPopupBtn.addEventListener("click", () => {
//     showSuccessMessage();
//     document.body.classList.toggle("show-popup");
// });

// hidePopupBtn.addEventListener("click", () => {
//     hideSuccessMessage();
//     showPopupBtn.click();
// });

