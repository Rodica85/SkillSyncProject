<?php
session_start();

require_once '../includes/database.php';
require_once '../includes/helpers.php';

if (!isLogged() || !userType('admin')) {
    header('Location: /');
    exit;
}

$action = $_GET['action'] ?? '';
$id = (int) ($_GET['id'] ?? 0);

if ($action === 'delete' && $id > 0) {
    $quiz = getQuiz($id);

    if (!$quiz) {
        flashMessageSet("Quiz not found.", "error");
    } else {
        // Delete all associated quiz questions
        dbExecute("DELETE FROM quiz_questions WHERE quiz_id = ?", [$id]);

        // Delete the quiz itself
        dbExecute("DELETE FROM quizzes WHERE id = ?", [$id]);

        flashMessageSet("Quiz deleted successfully.", "success");
    }

    header('Location: /dashboard/admin/quiz.php');
    exit;
}

// Invalid action or missing ID
flashMessageSet("Invalid delete request.", "error");
header('Location: /dashboard/admin/quiz.php');
exit;
