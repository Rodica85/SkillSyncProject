<?php
session_start();

include_once '../includes/database.php';
include_once '../includes/helpers.php';


switch ($_GET['action']) {
    case 'logout':
        session_destroy();
    break;
    case 'login':
        logIn();
    break;
    case 'signup':
        signUp();
    break;
}
header('Location: /');

function logIn() 
{
    if (isLogged()) {
        return;
    }

    if (empty($_POST["email"]) || empty($_POST["password"])) {
        flashMessageSet("Email and Password fields are required.", "error");
        return;
    }
    
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        flashMessageSet("The Email fields must contain a valid email address.", "error");
        return;
    }

    $email = $_POST["email"];
    $password = $_POST["password"];

    $user = getUserByEmail($email);
    if (empty($user)) {
        flashMessageSet("The User not found.", "error");
    } elseif (password_verify($password, $user["password"])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'name' => $user['username'],
            'email' => $user['email'],
            'type' => $user['type']
        ];
    } else {
        flashMessageSet("The Password does not match.", "error");
    }
}

function signUp()
{
    if (empty($_POST['username']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['confirm_password'])) {
        flashMessageSet("All the fields are required.", "error");
        return;
    }

    if ($_POST['password'] != $_POST['confirm_password']) {
        flashMessageSet("The Password fields does not match.", "error");
        return;
    }

    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        flashMessageSet("The Email fields must contain a valid email address.", "error");
        return;
    }

    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $user = getUserByEmail($email);
    if (!empty($user)) {
        flashMessageSet("The User with such email already exists.", "error");
        return;
    }

    $result = createUser([
        'email' => $email,
        'username' => $username,
        'password' => $password
    ]);
    
    if ($result == false) {
        flashMessageSet("Could not create the user.", "error");
        return;
    }

    flashMessageSet("Registration successful. Please sign in.", "success");
}