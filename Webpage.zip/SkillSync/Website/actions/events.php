<?php
session_start();
require_once '../includes/database.php';
require_once '../includes/helpers.php';

if (!isLogged()) {
    header('Location: /');
    exit;
}

$action = $_GET['action'] ?? '';
$eventId = $_GET['id_event'] ?? null;
$commentId = $_GET['id_comment'] ?? null;

switch ($action) {
    case 'add-comment':
        if (!empty($_POST['description']) && !empty($eventId)) {
            createComment([
                'user_id' => userId(),
                'event_id' => (int) $eventId,
                'message' => $_POST['description']
            ]);
            flashMessageSet('Comment added successfully.', 'success');
        } else {
            flashMessageSet('Invalid comment input.', 'danger');
        }
        break;

    case 'edit-comment':
        if (!empty($_POST['description']) && !empty($eventId) && !empty($commentId)) {
            updateComment([
                'id' => (int) $commentId,
                'user_id' => userId()
            ]);
            flashMessageSet('Comment updated successfully.', 'success');
        } else {
            flashMessageSet('Invalid comment update input.', 'danger');
        }
        break;

    case 'delete-comment':
        if (!empty($_GET['id'])) {
            deleteComment((int) $_GET['id']);
            flashMessageSet('Comment deleted successfully.', 'success');
        } else {
            flashMessageSet('Invalid comment ID.', 'danger');
        }
        break;

    case 'delete-event':
        if (!empty($_GET['id'])) {
            deleteEvent((int) $_GET['id']);
            flashMessageSet('Event deleted successfully.', 'success');
        } else {
            flashMessageSet('Invalid event ID.', 'danger');
        }
        break;

    default:
        flashMessageSet('Invalid action.', 'danger');
}

$redirectUrl = !empty($eventId) ? "/events/post.php?id={$eventId}" : '/dashboard';
header("Location: $redirectUrl");
exit;
