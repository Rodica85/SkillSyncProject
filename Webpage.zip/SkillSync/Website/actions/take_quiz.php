<?php
session_start();
require_once '../includes/database.php';
require_once '../includes/helpers.php';

if (!isLogged()) {
    header('Location: /login.php');
    exit;
}

$quiz_id = (int)($_GET['quiz_id'] ?? 0);
$question_number = (int)($_GET['q'] ?? 1);

if ($quiz_id === 0) {
    flashMessageSet("Invalid quiz ID.", "error");
    header('Location: /dashboard/');
    exit;
}

// Total question count
$total_questions = getOne("SELECT COUNT(*) as count FROM quiz_questions WHERE quiz_id = ?", [['type' => 'i', 'value' => $quiz_id]])['count'] ?? 0;

if ($question_number < 1 || $question_number > $total_questions) {
    flashMessageSet("Invalid question number.", "error");
    header('Location: /dashboard/');
    exit;
}

// Quiz info
$quiz = getOne("SELECT * FROM quizzes WHERE id = ?", [['type' => 'i', 'value' => $quiz_id]]);
if (!$quiz) {
    flashMessageSet("Quiz not found.", "error");
    header('Location: /dashboard/');
    exit;
}

// Handle answer submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_answer = strtoupper(trim($_POST['answer'] ?? ''));

    if (!in_array($selected_answer, ['A', 'B', 'C', 'D'])) {
        flashMessageSet("Please select a valid answer.", "error");
    } else {
        $current_question = getOne("SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY id ASC LIMIT 1 OFFSET ?", [
            ['type' => 'i', 'value' => $quiz_id],
            ['type' => 'i', 'value' => $question_number - 1]
        ]);

        $_SESSION['quiz_answers'][$quiz_id][$current_question['id']] = $selected_answer;

        if ($question_number < $total_questions) {
            header('Location: take_quiz.php?quiz_id=' . $quiz_id . '&q=' . ($question_number + 1));
            exit;
        } else {
            $show_results = true;
        }
    }
}

if (!isset($show_results)) {
    $question = getOne("SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY id ASC LIMIT 1 OFFSET ?", [
        ['type' => 'i', 'value' => $quiz_id],
        ['type' => 'i', 'value' => $question_number - 1]
    ]);
    $old_answer = $_SESSION['quiz_answers'][$quiz_id][$question['id']] ?? '';
} else {
    $questions = getMany("SELECT * FROM quiz_questions WHERE quiz_id = ?", [['type' => 'i', 'value' => $quiz_id]]);
    $answers = $_SESSION['quiz_answers'][$quiz_id] ?? [];

    $total = count($questions);
    $correct = 0;

    foreach ($questions as $q) {
        $qid = $q['id'];
        $user_answer = strtoupper(trim($answers[$qid] ?? ''));
        $correct_answer = strtoupper(trim($q['correct_option']));

        if ($user_answer === $correct_answer && $correct_answer !== '') {
            $correct++;
        }
    }

    $percentage = $total > 0 ? round(($correct / $total) * 100, 2) : 0;

    unset($_SESSION['quiz_answers'][$quiz_id]);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/" />
    <meta charset="UTF-8" />
    <title>Quiz: <?php echo htmlspecialchars($quiz['title']); ?></title>
    <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
<?php require_once '../includes/menu.php'; ?>
<?php require_once '../includes/system_message.php'; ?>

<div class="quiz-container">
    <h2><?php echo htmlspecialchars($quiz['title']); ?></h2>

    <?php if (!isset($show_results)): ?>
        <p>Question <?php echo $question_number; ?> of <?php echo $total_questions; ?></p>

        <form method="post">
            <fieldset class="quiz-question">
                <legend><?php echo htmlspecialchars($question['question_text']); ?></legend>

                <?php foreach (['a', 'b', 'c', 'd'] as $opt):
                    $opt_label = strtoupper($opt);
                    $opt_text = $question['option_' . $opt];
                ?>
                        <label class="quiz-option">
                        <input type="radio" name="answer" value="<?php echo $opt_label; ?>" required
                        <?php if ($old_answer === $opt_label) echo 'checked'; ?>>
                        <span><strong><?php echo $opt_label; ?>)</strong> <?php echo htmlspecialchars($opt_text); ?></span>
                    </label>
                <?php endforeach; ?>
            </fieldset>
            <input type="submit" value="<?php echo ($question_number === $total_questions) ? 'Finish Quiz' : 'Next Question'; ?>" class="default-btn">
        </form>

    <?php else: ?>
        <h3>Quiz Completed!</h3>
        <p>Total Questions: <?php echo $total; ?></p>
        <p>Correct Answers: <?php echo $correct; ?></p>
        <p>Your Score: <strong><?php echo $percentage; ?>%</strong></p>

        <a href="/dashboard/admin/quiz.php" class="default-btn">Back to Quiz List</a>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
</body>
</html>
