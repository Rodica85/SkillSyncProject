<?php
    session_start();
    require_once 'includes/helpers.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>SkillSync</title>
</head>
<body>
    <?php require_once 'includes/menu.php';?>

    <?php require_once 'includes/system_message.php';?>

    <?php require_once 'includes/footer.php';?>
</body>
</html>
