<?php if (!empty($message = flashMessageGet())) {?>
    <div class="system-message <?php echo $message['type'];?>">
        <div class="text">
            <?php echo $message['text'];?>
        </div>
        <button type="button">Close</button>
    </div>
<?php }?>