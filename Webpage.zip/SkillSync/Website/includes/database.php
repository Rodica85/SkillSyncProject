<?php
// includes/database.php

function getConnection() 
{
    $conn = new mysqli("localhost", "root", "", "userdb");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

function dbQuery($queryString, $params = [], $rowset = true) 
{
    $conn = getConnection();
    $stmt = $conn->prepare($queryString);
    if (!$stmt) {
        die("SQL error: " . $conn->error);
    }

    if (!empty($params)) {
        $types = '';
        $values = [];
        foreach ($params as $p) {
            $types   .= $p['type'];
            $values[] = $p['value'];
        }
        $stmt->bind_param($types, ...$values);
    }

    if (!$stmt->execute()) {
        die("Execute failed: " . $stmt->error);
    }

    $result = $rowset ? $stmt->get_result() : true;
    $stmt->close();
    $conn->close();
    return $result;
}

function getOne($sql, $params = []) 
{
    $res = dbQuery($sql, $params);
    if ($res && $res->num_rows > 0) {
        return $res->fetch_assoc();
    }
    return [];
}

function getMany($sql, $params = []) 
{
    $res  = dbQuery($sql, $params);
    $rows = [];
    if ($res && $res->num_rows > 0) {
        while ($r = $res->fetch_assoc()) {
            $rows[] = $r;
        }
    }
    return $rows;
}

// --- User ---
function getUserByEmail($email) {
    return getOne(
        "SELECT * FROM users WHERE email = ?", 
        [['type'=>'s','value'=>$email]]
    );
}

function createUser($u) {
    return dbQuery(
        "INSERT INTO users (username,password,email,type) VALUES (?,?,?,'user')",
        [
            ['type'=>'s','value'=>$u['username']],
            ['type'=>'s','value'=>$u['password']],
            ['type'=>'s','value'=>$u['email']],
        ],
        false
    );
}

// --- Event ---
function createEvent($e) {
    $date = $e['event_date'] ?? $e['date'];
    return dbQuery(
        "INSERT INTO events (user_id,title,description,youtube_url,event_date)
         VALUES (?,?,?,?,?)",
        [
            ['type'=>'i','value'=>$e['user_id']],
            ['type'=>'s','value'=>$e['title']],
            ['type'=>'s','value'=>$e['description']],
            ['type'=>'s','value'=>$e['youtube_url']],
            ['type'=>'s','value'=>$date],
        ],
        false
    );
}

function updateEvent($id, $e) {
    $date = $e['event_date'] ?? $e['date'];
    return dbQuery(
        "UPDATE events 
         SET title = ?, description = ?, event_date = ?, youtube_url = ?
         WHERE id = ?",
        [
            ['type'=>'s','value'=>$e['title']],
            ['type'=>'s','value'=>$e['description']],
            ['type'=>'s','value'=>$date],
            ['type'=>'s','value'=>$e['youtube_url']],
            ['type'=>'i','value'=>$id],
        ],
        false
    );
}

function getEvents($filters = []) {
    $sql  = "SELECT events.*, users.username, COUNT(comments.id) AS comments_counter
             FROM events
             LEFT JOIN users    ON events.user_id   = users.id
             LEFT JOIN comments ON events.id       = comments.event_id";
    $where = [];
    $params = [];

    if (!empty($filters['user_id'])) {
        $where[] = "events.user_id = ?";
        $params[] = ['type'=>'i','value'=>$filters['user_id']];
    }
    if (!empty($filters['keyword'])) {
        $where[] = "events.title LIKE ?";
        $params[] = ['type'=>'s','value'=>"%{$filters['keyword']}%"];
    }
    if (!empty($filters['from_date'])) {
        $where[] = "events.event_date >= ?";
        $params[] = ['type'=>'s','value'=>$filters['from_date']];
    }
    if (!empty($filters['to_date'])) {
        $where[] = "events.event_date <= ?";
        $params[] = ['type'=>'s','value'=>$filters['to_date']];
    }

    if ($where) {
        $sql .= " WHERE " . implode(' AND ', $where);
    }
    $sql .= " GROUP BY events.id";
    return getMany($sql, $params);
}

function getEvent($id) {
    return getOne(
        "SELECT events.*, users.username
         FROM events
         LEFT JOIN users ON events.user_id = users.id
         WHERE events.id = ?",
        [['type'=>'i','value'=>$id]]
    );
}

function deleteEvent($id) {
    return dbQuery(
        "DELETE FROM events WHERE id = ?",
        [['type'=>'i','value'=>$id]],
        false
    );
}

// --- Comment ---
function createComment($c) {
    return dbQuery(
        "INSERT INTO comments (user_id,event_id,message) VALUES (?,?,?)",
        [
            ['type'=>'i','value'=>$c['user_id']],
            ['type'=>'i','value'=>$c['event_id']],
            ['type'=>'s','value'=>$c['message']],
        ],
        false
    );
}

function getComments($f = []) {
    $sql = "SELECT comments.*, users.username 
            FROM comments
            LEFT JOIN users ON comments.user_id = users.id";
    $where = []; $params = [];

    if (!empty($f['event_id'])) {
        $where[] = "comments.event_id = ?";
        $params[] = ['type'=>'i','value'=>$f['event_id']];
    }

    if ($where) {
        $sql .= " WHERE " . implode(' AND ', $where);
    }
    return getMany($sql, $params);
}

function getComment($id) {
    return getOne(
        "SELECT * FROM comments WHERE id = ?",
        [['type'=>'i','value'=>$id]]
    );
}

function deleteComment($id) {
    return dbQuery(
        "DELETE FROM comments WHERE id = ?",
        [['type'=>'i','value'=>$id]],
        false
    );
}
function updateComment($c) {
    return dbQuery(
        "UPDATE comments SET message = ? WHERE id = ? AND user_id = ?",
        [
            ['type'=>'s','value'=>$c['message']],
            ['type'=>'i','value'=>$c['id']],
            ['type'=>'i','value'=>$c['user_id']],
        ],
        false
    );
}

// --- Quiz ---
function createQuiz($q) {
    return dbQuery(
        "INSERT INTO quizzes (event_id,title,created_at)
         VALUES (?,?,NOW())",
        [
            ['type'=>'i','value'=>$q['event_id']],
            ['type'=>'s','value'=>$q['title']],
        ],
        false
    );
}

function getAllQuizzes() {
    return getMany("SELECT * FROM quizzes ORDER BY created_at DESC", []);
}

function getQuiz($id) {
    return getOne("SELECT * FROM quizzes WHERE id = ?", [['type'=>'i','value'=>$id]]);
}

function updateQuiz($id, $q) {
    return dbQuery(
        "UPDATE quizzes SET event_id = ?, title = ? WHERE id = ?",
        [
            ['type'=>'i','value'=>$q['event_id']],
            ['type'=>'s','value'=>$q['title']],
            ['type'=>'i','value'=>$id],
        ],
        false
    );
}

function deleteQuiz($id) {
    return dbQuery(
        "DELETE FROM quizzes WHERE id = ?",
        [['type'=>'i','value'=>$id]],
        false
    );
}

// --- Quiz Questions ---
function createQuizQuestion($qq) {
    return dbQuery(
        "INSERT INTO quiz_questions 
         (quiz_id,question_text,option_a,option_b,option_c,option_d,correct_option)
         VALUES (?,?,?,?,?,?,?)",
        [
            ['type'=>'i','value'=>$qq['quiz_id']],
            ['type'=>'s','value'=>$qq['question_text']],
            ['type'=>'s','value'=>$qq['option_a']],
            ['type'=>'s','value'=>$qq['option_b']],
            ['type'=>'s','value'=>$qq['option_c']],
            ['type'=>'s','value'=>$qq['option_d']],
            ['type'=>'s','value'=>$qq['correct_option']],
        ],
        false
    );
}

function getQuizQuestions($quiz_id) {
    return getMany(
        "SELECT * FROM quiz_questions
         WHERE quiz_id = ?
         ORDER BY id ASC",
        [['type'=>'i','value'=>$quiz_id]]
    );
}

function updateQuizQuestion($id, $qq) {
    return dbQuery(
        "UPDATE quiz_questions
         SET question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=?
         WHERE id=?",
        [
            ['type'=>'s','value'=>$qq['question_text']],
            ['type'=>'s','value'=>$qq['option_a']],
            ['type'=>'s','value'=>$qq['option_b']],
            ['type'=>'s','value'=>$qq['option_c']],
            ['type'=>'s','value'=>$qq['option_d']],
            ['type'=>'s','value'=>$qq['correct_option']],
            ['type'=>'i','value'=>$id],
        ],
        false
    );
}

function deleteQuizQuestion($id) {
    return dbQuery(
        "DELETE FROM quiz_questions WHERE id = ?",
        [['type'=>'i','value'=>$id]],
        false
    );
}

function dbExecute($sql, $params = []) {
    $conn = getConnection();
    $stmt = $conn->prepare($sql);

    if (!empty($params)) {
        $types = str_repeat('i', count($params)); // assumes all integers
        $stmt->bind_param($types, ...$params);
    }

    $result = $stmt->execute();
    $stmt->close();
    $conn->close();

    return $result;
}
