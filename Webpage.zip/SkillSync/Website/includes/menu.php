<?php
    // Get current path
    $currentPath = $_SERVER['REQUEST_URI'];
?>

<header>
    <nav class="navbar">
        <span class="hamburger-btn material-symbols-rounded">menu</span>
        <a href="/" class="logo">
            <h2>SkillSync</h2>
        </a>
        <ul class="links">
            <span class="close-btn material-symbols-rounded">close</span>
            <li><a href="/">Home</a></li>

            <?php if (isLogged()) { ?>
                <li><a href="/events">Video</a></li>
                <li><a href="/dashboard/admin/quiz.php">Quiz</a></li>
                <?php if (userType('admin')): ?>
                    <li><a href="/dashboard">Dashboard</a></li>
                <?php endif; ?>
            <?php } else { ?>
                <li><a href="#" class="login-form">Events</a></li>
                <li><a href="#" class="login-form">Quiz</a></li>
            <?php } ?>
        </ul>

        <?php if (!isLogged()) { ?>
            <button class="default-btn login-form">LOG IN</button>
        <?php } else { ?>
            <a class="default-btn" href="/actions/auth.php?action=logout">LOGOUT</a>
        <?php } ?>
    </nav>
</header>

<?php if ($currentPath == '/' || $currentPath == '/index.php') : ?>
    <!-- Hero Section Start -->
    <section class="hero-section">
        <div class="hero-content">
            <h1>Welcome to SkillSync</h1>
            <h3>Empowering everyone to stay safe online.</h3>
            <p>
                SkillSync is an interactive learning platform designed to raise awareness about common cybersecurity threats in the UK.
                Through engaging videos and easy-to-follow quizzes, we make cybersecurity education accessible, practical, and memorable —
                even for those without a technical background. Whether you're new to cybersecurity or looking to refresh your knowledge,
                SkillSync helps you build safer digital habits in just minutes.
            </p>
        </div>
    </section>
    <!-- Hero Section End -->
<?php endif; ?>
