<?php
define("UPLOAD_EVENTS_IMAGE_PATH", 'uploads/events');
?>