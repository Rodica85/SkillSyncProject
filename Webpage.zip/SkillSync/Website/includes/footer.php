<script src="assets/js/jquery.js?v=1" defer></script>
<script src="assets/js/script.js?v=<?php echo time();?>" defer></script>

<?php if (!isLogged()) {?>
    <script src="assets/js/auth.js?v=<?php echo time();?>" defer></script>
    <div class="blur-bg-overlay"></div>
    <div class="auth-form-popup">
        <span class="close-btn material-symbols-rounded">close</span>
        <div class="form-box login">
            <div class="form-details">
                <h2>Welcome Back</h2>
                <p>Please log in using your personal information to stay connected with us.</p>
            </div>


            <div class="form-content">
                <h2>LOGIN</h2>
                <form action="/actions/auth.php?action=login" method="post">
                    <div class="input-field">
                        <input type="email" name="email" required>
                        <label>Email</label>
                    </div>
                    <div class="input-field">
                        <input type="password" name="password" required>
                        <label>Password</label>
                    </div>
                    <a href="#" class="forgot-pass-link">Forgot password?</a>
                    <button type="submit">Log In</button>
                </form>
                <div class="bottom-link">
                    Don't have an account?
                    <a href="#" id="signup-link">Signup</a>
                </div>
            </div>
        </div>

        <div class="form-box signup">
            <div class="form-details">
                <h2>Create Account</h2>
                <p>To become a part of our community, please sign up using your personal information.</p>
            </div>
            <div class="form-content">
                <h2>SIGNUP</h2>
                <form action="/actions/auth.php?action=signup" method="post">
                    <div class="input-field">
                        <input type="text" name="username" required>
                        <label>Name</label>
                    </div>
                    <div class="input-field">
                        <input type="email" name="email" required>
                        <label>Email</label>
                    </div>
                    <div class="input-field">
                        <input type="password" name="password" required>
                        <label>Password</label>
                    </div>
                    <div class="input-field">
                        <input type="password" name="confirm_password" required>
                        <label>Confirm Password</label>
                    </div>
                    <div class="policy-text">
                        <input type="checkbox" id="policy" required>
                        <label for="policy">
                            I agree to the
                            <a href="#" class="option">Terms & Conditions</a>
                        </label>
                    </div>
                    <button type="submit">Sign Up</button>
                </form>
                <div id="success-message" style="display: none;">
                    Registration successful! Welcome to our community.
                </div>
                <div class="bottom-link">
                    Already have an account?
                    <a href="#" id="login-link">Login</a>
                </div>
            </div>
        </div>
    </div>
<?php }?>