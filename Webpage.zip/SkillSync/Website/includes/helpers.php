<?php
// includes/helpers.php

require_once 'constants.php';

function uploadEventImagePath(string $filename)
{
    return $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . UPLOAD_EVENTS_IMAGE_PATH . DIRECTORY_SEPARATOR . $filename;
}

function uploadEventImageFolder()
{
    return $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . UPLOAD_EVENTS_IMAGE_PATH;
}

function linkEventImagePath(string $filename)
{
    return UPLOAD_EVENTS_IMAGE_PATH . DIRECTORY_SEPARATOR . $filename;
}

function dump($array)
{
    echo '<pre>';
    print_r($array);
    echo '</pre>';
}

function dd($array)
{
    dump($array);
    die;
}

function isLogged()
{
    return !empty($_SESSION['user']);
}

function userType($type)
{
    if (empty($_SESSION['user'])) {
        return false;
    }
    return $_SESSION['user']['type'] === $type;
}

function userName()
{
    return $_SESSION['user']['username'] ?? null;
}

function userId()
{
    return $_SESSION['user']['id'] ?? null;
}

function redirectToDashboard()
{
    header('Location: /dashboard');
    exit;
}

function redirectToEvent($id)
{
    header('Location: /events/post.php?id=' . $id);
    exit;
}

function flashMessageSet($message, $type)
{
    $_SESSION['flash_message'] = [
        'text' => $message,
        'type' => $type
    ];
}

function flashMessageGet()
{
    $flashData = $_SESSION['flash_message'] ?? null;
    unset($_SESSION['flash_message']);
    return $flashData;
}
