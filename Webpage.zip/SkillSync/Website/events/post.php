<?php
session_start();

include_once '../includes/database.php';
require_once '../includes/helpers.php';

if (!isLogged()) {
    header('Location: /');
    exit;
}

if (empty($_GET['id']) || (int) $_GET['id'] === 0 || empty($event = getEvent((int) $_GET['id']))) {
    header('Location: /events');
    exit;
}

if (!empty($_GET['id_comment']) && (int) $_GET['id_comment'] !== 0 && empty($editComment = getComment((int) $_GET['id_comment']))) {
    header('Location: /events');
    exit;
}

$comments = getComments(['id_event' => $event['id']]);

// Extract YouTube video ID
$youtubeUrl = $event['youtube_url'] ?? '';
$videoId = null;

if (preg_match('/youtu\.be\/([^\?&]+)/', $youtubeUrl, $matches)) {
    $videoId = $matches[1];
} elseif (preg_match('/youtube\.com.*[?&]v=([^&]+)/', $youtubeUrl, $matches)) {
    $videoId = $matches[1];
}

$youtubeEmbed = $videoId ? "https://www.youtube.com/embed/$videoId" : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>SkillSync</title>
</head>
<body>
<?php require_once '../includes/menu.php'; ?>
<?php require_once '../includes/system_message.php'; ?>

<div class="container">
    <h2><?php echo htmlspecialchars($event['title']); ?></h2>
    <div class="event-wrapper">
        <div class="event-date">
            <?php echo date('j M, Y', strtotime($event['event_date'])); ?>
        </div>
        <div class="event-video">
            <?php if ($youtubeEmbed): ?>
                <iframe width="100%" height="400" src="<?php echo $youtubeEmbed; ?>" 
                        title="YouTube video player" frameborder="0" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowfullscreen>
                </iframe>
            <?php else: ?>
                <div class="no-preview">No video available</div>
            <?php endif; ?>
        </div>
        <div class="event-description">
            <?php echo nl2br(htmlspecialchars($event['description'])); ?>
        </div>
    </div>

    <h3>Comments</h3>
    <div class="add-event-form">
        <?php $formAction = !empty($editComment) ? 'edit-comment' : 'add-comment'; ?>
        <form action='/actions/events.php?action=<?php echo $formAction; ?>&id_event=<?php echo $event['id']; ?>' method='post'>
            <div>
                <label for="description">Message</label>
                <textarea name='description' rows="10" required><?php echo !empty($editComment) ? htmlspecialchars($editComment['message']) : ''; ?></textarea>
            </div>
            <div class="buttons">
                <input type='submit' name='submit_data' value='Submit' class="default-btn">
            </div>
        </form>
    </div>

    <?php if (!empty($comments)) { ?>
        <?php foreach ($comments as $comment) { ?>
            <div class="wrapper-comments">
                <div class="comments-item">
                    <div class="comment-info">
                        <div class="comment-date">
                            <?php echo date('j M, Y H:i', strtotime($comment['created_on'])); ?>
                        </div>
                        <div class="comment-username">
                            <?php echo htmlspecialchars($comment['username']); ?>
                        </div>
                    </div>
                    <div class="comment-text"><?php echo nl2br(htmlspecialchars($comment['message'])); ?></div>
                    <?php if ($comment['user_id'] == userId() || userType('admin')) { ?>
                        <div class="actions">
                          <a href="/actions/events.php?action=delete-comment&id=<?php echo $comment['id']; ?>" class="danger-btn delete-btn">Delete</a>
                        </div>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>
    <?php } ?>
</div>

<?php require_once '../includes/footer.php'; ?>
</body>
</html>
