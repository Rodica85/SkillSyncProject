<?php
session_start();

include_once '../includes/database.php';
require_once '../includes/helpers.php';

if (!isLogged()) {
    header('Location: /');
    exit;
}

$eventsParams = [];
if (!empty($_GET['keyword'])) {
    $eventsParams['keyword'] = $_GET['keyword'];
}
if (!empty($_GET['from'])) {
    $fromDate = date_create($_GET['from']);
    if ($fromDate) {
        $eventsParams['from_date'] = date_format($fromDate, 'Y-m-d');
    }
}
if (!empty($_GET['to'])) {
    $toDate = date_create($_GET['to']);
    if ($toDate) {
        $eventsParams['to_date'] = date_format($toDate, 'Y-m-d');
    }
}

$events = getEvents($eventsParams);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/" />
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
      href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="assets/css/style.css" />
    <title>SkillSync</title>
</head>
<body>
    <?php require_once '../includes/menu.php'; ?>

    <?php require_once '../includes/system_message.php'; ?>

    <div class="container">
        <h2>Events</h2>
        <form action="/events" method="get" class="filter-form">
            <?php if (!empty($eventsParams)) { ?>
                <a href="/events" class="default-btn cancel-btn">Cancel</a>
            <?php } ?>
        </form>

        <div class="events-wrapper">
            <?php if (!empty($events)) { ?>
                <?php foreach ($events as $event) { ?>
                    <a href="<?php echo '/events/post.php?id=' . (int)$event['id']; ?>" class="event-box">
                        <div class="event-box_image">
                            <?php if (!empty($event['image_path'])): ?>
                                <img
                                  src="<?php echo htmlspecialchars(linkEventImagePath($event['image_path']), ENT_QUOTES); ?>"
                                  alt="<?php echo htmlspecialchars($event['title'], ENT_QUOTES); ?>"
                                />
                            <?php elseif (!empty($event['youtube_url'])): ?>
                                <?php
                                    $url = $event['youtube_url'];
                                    $videoId = null;
                                    $host = parse_url($url, PHP_URL_HOST);
                                    if (strpos($host, 'youtu.be') !== false) {
                                        $videoId = ltrim(parse_url($url, PHP_URL_PATH), '/');
                                    } else {
                                        parse_str(parse_url($url, PHP_URL_QUERY), $videoParams);
                                        $videoId = $videoParams['v'] ?? null;
                                    }
                                ?>
                                <?php if ($videoId): ?>
                                    <img
                                      src="https://img.youtube.com/vi/<?php echo htmlspecialchars($videoId, ENT_QUOTES); ?>/hqdefault.jpg"
                                      alt="YouTube video thumbnail"
                                    />
                                <?php else: ?>
                                    <div class="no-preview">No preview available</div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="no-preview">No preview available</div>
                            <?php endif; ?>
                        </div>

                        <div class="event-box_info">
                            <div class="event-date">
                                <?php echo date('j M, Y', strtotime($event['event_date'])); ?>
                            </div>
                            <div class="event-comments_counter">
                                Comments: <?php echo (int)$event['comments_counter']; ?>
                            </div>
                        </div>
                        <div class="event-box_title">
                            <?php echo htmlspecialchars($event['title'], ENT_QUOTES); ?>
                        </div>
                    </a>
                <?php } ?>
            <?php } else { ?>
                <p>No events found.</p>
            <?php } ?>
        </div>
    </div>

    <?php require_once '../includes/footer.php'; ?>
</body>
</html>
